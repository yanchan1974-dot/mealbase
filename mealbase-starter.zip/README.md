# MealBase (Starter)

A minimal, hackable backend to auto-build a structured database of your meals from **photos** and **voice/text notes**, while preserving raw inputs and versioned structured outputs.

**MVP goals (1–2 days of work):**
- POST `/ingest/photo` to upload a meal photo with optional free text.
- POST `/ingest/voice` to upload a voice note (ASR transcribed to text).
- POST `/ingest/text` for quick text-only entries.
- Auto-create a **Meal** with **Entries** and **Items**; keep raw files in `/data/`.
- Simple rules engine (`rules.py`) to parse quantities like “nuts 1/2”, “no skin”, etc.
- GET `/meals?date=YYYY-MM-DD` and `/meals/{id}` to retrieve structured data.
- Export to CSV or Google Sheets later via `/export/*` endpoints (stubs included).

## Architecture (MVP)
- **FastAPI** backend
- **SQLite** (swap to Postgres via `DATABASE_URL` later)
- **Pydantic** schemas, SQLAlchemy models
- **Services** stubs:
  - `vision.py` — food detection/segmentation placeholder
  - `ocr.py` — OCR placeholder
  - `asr.py` — speech-to-text placeholder
  - `llm.py` — extraction/normalization/merge logic placeholder
  - `rules.py` — your domain rules (e.g., “семечки 1/3, орехи 1/2”)
- **Versioning**: any derived nutrition facts are stored in `MealVersion` rows with a `source` and `hash` of the prompt/raw to ensure traceability. Raw media are never overwritten.

## Data Model (ERD)
**User** 1—* **Meal**
**Meal** 1—* **MealEntry** (each input: photo, voice, text)
**Meal** 1—* **MealItem** (e.g., “buckwheat 200g”, “nuts 1/2”)
**MealVersion** (snapshots of computed nutrition/macros with provenance)
**Tag** (e.g., “Yan’s Health”, “fasting”, “no skin”)

```
User(id) ──< Meal(id, user_id, started_at, label, context)
Meal ──< MealEntry(id, meal_id, type[photo|voice|text], path, text, meta)
Meal ──< MealItem(id, meal_id, name, qty, unit, notes)
Meal ──< MealVersion(id, meal_id, macros_json, micronutrients_json, source, created_at, hash)
Meal >──< Tag(id, name) via MealTag(meal_id, tag_id)
```

## Quickstart
```bash
# 1) Create virtualenv
python3 -m venv .venv && source .venv/bin/activate

# 2) Install deps
pip install -r requirements.txt

# 3) Run
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000/docs for interactive API.

## Roadmap (near-term)
- Google Sheets sync (`/export/google_sheets`)
- Telegram bot webhook for instant capture
- OCR on handwritten notes
- Food-photo model (open weights or API)
- Macro DB integrations (USDA/SimpleFood/Edamam) with unit conversion
- Device imports (WHOOP/Airofit) to align meals with strain/sleep

## Security & Privacy
- Local-first; all raw inputs stored under `/data/` by default.
- Provenance and versioning: never mutate past versions; append only.
- API key middleware (simple token) for non-public deployments.
- Future: end-to-end encryption for mobile capture.

---

MIT License. Have fun and break things—then make them robust.
