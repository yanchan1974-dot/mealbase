# Placeholder for a vision model that detects foods from an image.
# For MVP, return empty list and rely on text/voice notes and rules.
from typing import List, Dict

def detect_food_items(image_path: str) -> List[Dict]:
    # TODO: integrate a real model or API later
    return []
