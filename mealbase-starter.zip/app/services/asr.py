# Placeholder ASR service. You could plug OpenAI Whisper or a local model.
def transcribe_voice(audio_path: str) -> str:
    return "voice note (transcription placeholder)"
