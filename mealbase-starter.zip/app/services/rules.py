# Domain rules for Yan's preferences (no skin, fasting tags, etc.).
from typing import List, Dict

def apply_rules(items: List[Dict]) -> List[Dict]:
    # TODO: implement normalization, merging, portion scaling
    # e.g., map "1/2" to 0.5, ensure units, strip duplicates
    return items
