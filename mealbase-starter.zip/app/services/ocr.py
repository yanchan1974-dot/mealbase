# Placeholder OCR service. You could plug pytesseract or an API here.
def extract_text_from_image(image_path: str) -> str:
    return ""
