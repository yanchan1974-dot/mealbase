# Placeholder extraction using rules/heuristics for MVP.
# Later, replace with an LLM call and a nutrition DB match (USDA/SimpleFood).
from typing import List, Dict, Tuple

def derive_items_and_macros(note_text: str, detected_items: List[Dict]) -> Tuple[List[Dict], Dict]:
    # Super-naive parsing for phrases like "nuts 1/2", "семечки 1/3", "гречка 200 г"
    items: List[Dict] = []
    text = (note_text or "").lower()
    if "гречк" in text:
        items.append({"name": "buckwheat (гречка)", "qty": 200.0, "unit": "g", "notes": ""})
    if "семеч" in text:
        items.append({"name": "seeds (семечки)", "qty": 1/3, "unit": "portion", "notes": ""})
    if "орех" in text:
        items.append({"name": "nuts (орехи)", "qty": 0.5, "unit": "portion", "notes": ""})
    if "печень трески" in text:
        items.append({"name": "cod liver", "qty": 0.25, "unit": "can", "notes": ""})
    # Merge detected items (if any)
    for di in detected_items:
        items.append(di)
    # Dummy macros — replace with real calculation later
    macros = {"protein_g": 20, "carbs_g": 60, "fat_g": 15, "kcal": 550, "method": "placeholder"}
    return items, macros
