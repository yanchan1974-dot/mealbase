import os
import asyncio
import logging
from datetime import datetime
from io import BytesIO

import aiohttp
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, CommandHandler, ContextTypes, filters

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("mealbase-bot")

API_URL = os.getenv("MEALBASE_API_URL", "http://localhost:8000")
TOKEN = os.getenv("TELEGRAM_TOKEN")

async def healthcheck(session: aiohttp.ClientSession) -> bool:
    try:
        async with session.get(API_URL + "/meals") as r:
            return r.status in (200, 422)  # 422 if no params—ok
    except Exception:
        return False

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Привет! Я бот MealBase. Отправь мне фото еды, голосовую заметку или текст — я сложу это в твою базу.
"
        "Команды:
"
        "• Просто пришли фото/голос/текст — я распознаю и занесу в приём пищи.
"
        "• /today — показать сегодняшние приёмы.
"
    )

async def today(update: Update, context: ContextTypes.DEFAULT_TYPE):
    async with aiohttp.ClientSession() as session:
        async with session.get(API_URL + "/meals", params={"date_str": datetime.now().date().isoformat()}) as r:
            if r.status != 200:
                await update.message.reply_text("Бэкенд недоступен. Проверь развёртывание.")
                return
            data = await r.json()
    if not data:
        await update.message.reply_text("Сегодня ещё нет записей.")
        return
    lines = []
    for m in data:
        mac = m.get("latest_macros", {}) or {}
        line = f"#{m['id']} • {m['started_at']} • kcal: {mac.get('kcal','?')} P:{mac.get('protein_g','?')} C:{mac.get('carbs_g','?')} F:{mac.get('fat_g','?')}"
        lines.append(line)
    await update.message.reply_text("\n".join(lines))

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text or ""
    async with aiohttp.ClientSession() as session:
        form = aiohttp.FormData()
        form.add_field("text", text)
        form.add_field("user_id", "1")
        form.add_field("started_at", datetime.now().isoformat())
        async with session.post(API_URL + "/ingest/text", data=form) as r:
            if r.status != 200:
                await update.message.reply_text("Не удалось сохранить текст.")
                return
            meal = await r.json()
    await update.message.reply_text(f"OK. Сохранил текст в приём #{meal['id']}.")

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    photo = update.message.photo[-1]  # best quality
    file = await context.bot.get_file(photo.file_id)
    content = await file.download_as_bytearray()
    async with aiohttp.ClientSession() as session:
        form = aiohttp.FormData()
        form.add_field("image", BytesIO(content), filename="photo.jpg", content_type="image/jpeg")
        form.add_field("user_id", "1")
        form.add_field("note", update.message.caption or "")
        form.add_field("started_at", datetime.now().isoformat())
        async with session.post(API_URL + "/ingest/photo", data=form) as r:
            if r.status != 200:
                await update.message.reply_text("Не удалось сохранить фото.")
                return
            meal = await r.json()
    await update.message.reply_text(f"Фото сохранено в приём #{meal['id']}.")

async def handle_voice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    voice = update.message.voice
    file = await context.bot.get_file(voice.file_id)
    # Telegram voice is OGG/Opus
    content = await file.download_as_bytearray()
    async with aiohttp.ClientSession() as session:
        form = aiohttp.FormData()
        form.add_field("audio", BytesIO(content), filename="voice.ogg", content_type="audio/ogg")
        form.add_field("user_id", "1")
        form.add_field("started_at", datetime.now().isoformat())
        async with session.post(API_URL + "/ingest/voice", data=form) as r:
            if r.status != 200:
                await update.message.reply_text("Не удалось сохранить голосовую заметку.")
                return
            meal = await r.json()
    await update.message.reply_text(f"Голосовая сохранена в приём #{meal['id']}.")

def main():
    if not TOKEN:
        raise RuntimeError("TELEGRAM_TOKEN не задан")
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("today", today))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.VOICE, handle_voice))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.run_polling()

if __name__ == "__main__":
    main()
