from pydantic import BaseModel
from typing import Optional, List, Dict, Any

class MealEntryOut(BaseModel):
    id: int
    type: str
    path: Optional[str]
    text: str
    meta: Dict[str, Any]

class MealItemOut(BaseModel):
    id: int
    name: str
    qty: Optional[float] = None
    unit: Optional[str] = None
    notes: Optional[str] = None

class MealOut(BaseModel):
    id: int
    started_at: str
    label: Optional[str] = None
    context: Optional[str] = None
    entries: List[MealEntryOut]
    items: List[MealItemOut]
    latest_macros: Dict[str, Any]
    tags: List[str]

# For future: explicit create models
class MealItemCreate(BaseModel):
    name: str
    qty: Optional[float] = None
    unit: Optional[str] = None
    notes: Optional[str] = None

class MealCreate(BaseModel):
    started_at: Optional[str] = None
    label: Optional[str] = None
    context: Optional[str] = None
    items: Optional[List[MealItemCreate]] = None
