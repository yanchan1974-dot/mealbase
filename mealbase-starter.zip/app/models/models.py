from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, JSON, Text, Float, UniqueConstraint, Table
from sqlalchemy.orm import relationship, Session
from datetime import datetime
from .db import Base
from .schema import MealOut, MealEntryOut, MealItemOut

MealTag = Table(
    "meal_tags",
    Base.metadata,
    Column("meal_id", ForeignKey("meals.id"), primary_key=True),
    Column("tag_id", ForeignKey("tags.id"), primary_key=True),
)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=True)

class Meal(Base):
    __tablename__ = "meals"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    started_at = Column(DateTime, default=datetime.utcnow, index=True)
    label = Column(String, nullable=True)
    context = Column(Text, nullable=True)

    entries = relationship("MealEntry", back_populates="meal", cascade="all, delete-orphan")
    items = relationship("MealItem", back_populates="meal", cascade="all, delete-orphan")
    versions = relationship("MealVersion", back_populates="meal", cascade="all, delete-orphan")
    tags = relationship("Tag", secondary=MealTag, back_populates="meals")

    def to_out(self, db: Session) -> MealOut:
        latest = self.versions[-1] if self.versions else None
        return MealOut(
            id=self.id,
            started_at=self.started_at.isoformat(),
            label=self.label,
            context=self.context,
            entries=[e.to_out() for e in self.entries],
            items=[i.to_out() for i in self.items],
            latest_macros=latest.macros_json if latest else {},
            tags=[t.name for t in self.tags],
        )

class MealEntry(Base):
    __tablename__ = "meal_entries"
    id = Column(Integer, primary_key=True, index=True)
    meal_id = Column(Integer, ForeignKey("meals.id"), nullable=False, index=True)
    type = Column(String, nullable=False)  # photo | voice | text
    path = Column(String, nullable=True)   # file path for photo/voice
    text = Column(Text, nullable=True)
    meta = Column(JSON, nullable=True, default={})

    meal = relationship("Meal", back_populates="entries")

    def to_out(self) -> MealEntryOut:
        return MealEntryOut(id=self.id, type=self.type, path=self.path, text=self.text or "", meta=self.meta or {})

class MealItem(Base):
    __tablename__ = "meal_items"
    id = Column(Integer, primary_key=True, index=True)
    meal_id = Column(Integer, ForeignKey("meals.id"), nullable=False, index=True)
    name = Column(String, nullable=False)
    qty = Column(Float, nullable=True)
    unit = Column(String, nullable=True)
    notes = Column(Text, nullable=True)

    meal = relationship("Meal", back_populates="items")

    def to_out(self) -> MealItemOut:
        return MealItemOut(id=self.id, name=self.name, qty=self.qty, unit=self.unit, notes=self.notes)

class MealVersion(Base):
    __tablename__ = "meal_versions"
    id = Column(Integer, primary_key=True, index=True)
    meal_id = Column(Integer, ForeignKey("meals.id"), nullable=False, index=True)
    macros_json = Column(JSON, nullable=True, default={})
    micronutrients_json = Column(JSON, nullable=True, default={})
    source = Column(String, nullable=True)
    hash = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    meal = relationship("Meal", back_populates="versions")

class Tag(Base):
    __tablename__ = "tags"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)

    meals = relationship("Meal", secondary=MealTag, back_populates="tags")
