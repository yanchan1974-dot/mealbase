from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException
from fastapi.responses import JSONResponse
from typing import Optional, List
from .models.db import Base, engine, SessionLocal
from .models.schema import MealCreate, MealOut, MealEntryOut, MealItemCreate, MealItemOut
from .models.models import User, Meal, MealEntry, MealItem, MealVersion, Tag, MealTag
from sqlalchemy.orm import Session
from datetime import datetime, date
import os, uuid, json

from .services.asr import transcribe_voice
from .services.vision import detect_food_items
from .services.ocr import extract_text_from_image
from .services.llm import derive_items_and_macros
from .services.rules import apply_rules

app = FastAPI(title="MealBase")

Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

DATA_DIR = os.getenv("DATA_DIR", "/mnt/data/mealbase-starter/data")

@app.post("/ingest/photo", response_model=MealOut)
async def ingest_photo(
    image: UploadFile = File(...),
    user_id: int = Form(1),
    note: Optional[str] = Form(None),
    started_at: Optional[str] = Form(None),
    db: Session = Depends(get_db),
):
    # Persist file
    ext = os.path.splitext(image.filename)[1] or ".jpg"
    path = os.path.join(DATA_DIR, f"{uuid.uuid4().hex}{ext}")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(await image.read())

    # Create or attach to meal
    started_dt = datetime.fromisoformat(started_at) if started_at else datetime.now()
    meal = Meal(user_id=user_id, started_at=started_dt, label=None, context=None)
    db.add(meal); db.commit(); db.refresh(meal)

    entry = MealEntry(meal_id=meal.id, type="photo", path=path, text=note or "", meta={})
    db.add(entry); db.commit(); db.refresh(entry)

    # Optional pipelines (stubbed)
    ocr_text = extract_text_from_image(path) or ""
    detected = detect_food_items(path) or []
    merged_note = " ".join([note or "", ocr_text]).strip()

    # LLM extraction (stubbed): items + macros
    items, macros = derive_items_and_macros(merged_note, detected)

    # Apply domain rules
    items = apply_rules(items)

    # Persist items
    for it in items:
        db.add(MealItem(meal_id=meal.id, name=it.get("name"), qty=it.get("qty"), unit=it.get("unit"), notes=it.get("notes")))
    db.commit()

    # Version snapshot
    db.add(MealVersion(meal_id=meal.id, macros_json=macros, micronutrients_json={}, source="auto_pipeline", hash=str(uuid.uuid4())))
    db.commit()

    db.refresh(meal)
    return meal.to_out(db)

@app.post("/ingest/voice", response_model=MealOut)
async def ingest_voice(
    audio: UploadFile = File(...),
    user_id: int = Form(1),
    started_at: Optional[str] = Form(None),
    db: Session = Depends(get_db),
):
    # Persist file
    ext = os.path.splitext(audio.filename)[1] or ".wav"
    path = os.path.join(DATA_DIR, f"{uuid.uuid4().hex}{ext}")
    with open(path, "wb") as f:
        f.write(await audio.read())

    # Transcribe
    text = transcribe_voice(path)

    started_dt = datetime.fromisoformat(started_at) if started_at else datetime.now()
    meal = Meal(user_id=user_id, started_at=started_dt, label=None, context=None)
    db.add(meal); db.commit(); db.refresh(meal)

    entry = MealEntry(meal_id=meal.id, type="voice", path=path, text=text, meta={})
    db.add(entry); db.commit(); db.refresh(entry)

    items, macros = derive_items_and_macros(text, [])
    items = apply_rules(items)
    for it in items:
        db.add(MealItem(meal_id=meal.id, name=it.get("name"), qty=it.get("qty"), unit=it.get("unit"), notes=it.get("notes")))
    db.commit()
    db.add(MealVersion(meal_id=meal.id, macros_json=macros, micronutrients_json={}, source="auto_pipeline", hash=str(uuid.uuid4())))
    db.commit()

    return meal.to_out(db)

@app.post("/ingest/text", response_model=MealOut)
async def ingest_text(
    text: str = Form(...),
    user_id: int = Form(1),
    started_at: Optional[str] = Form(None),
    db: Session = Depends(get_db),
):
    started_dt = datetime.fromisoformat(started_at) if started_at else datetime.now()
    meal = Meal(user_id=user_id, started_at=started_dt, label=None, context=None)
    db.add(meal); db.commit(); db.refresh(meal)

    entry = MealEntry(meal_id=meal.id, type="text", path=None, text=text, meta={})
    db.add(entry); db.commit(); db.refresh(entry)

    items, macros = derive_items_and_macros(text, [])
    items = apply_rules(items)
    for it in items:
        db.add(MealItem(meal_id=meal.id, name=it.get("name"), qty=it.get("qty"), unit=it.get("unit"), notes=it.get("notes")))
    db.commit()
    db.add(MealVersion(meal_id=meal.id, macros_json=macros, micronutrients_json={}, source="auto_pipeline", hash=str(uuid.uuid4())))
    db.commit()

    return meal.to_out(db)

@app.get("/meals", response_model=List[MealOut])
def list_meals(date_str: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(Meal)
    if date_str:
        d = date.fromisoformat(date_str)
        start = datetime(d.year, d.month, d.day)
        end = datetime(d.year, d.month, d.day, 23, 59, 59)
        q = q.filter(Meal.started_at >= start, Meal.started_at <= end)
    meals = q.order_by(Meal.started_at.desc()).all()
    return [m.to_out(db) for m in meals]

@app.get("/meals/{meal_id}", response_model=MealOut)
def get_meal(meal_id: int, db: Session = Depends(get_db)):
    meal = db.get(Meal, meal_id)
    if not meal:
        raise HTTPException(404, "Meal not found")
    return meal.to_out(db)

# Stubs for export (to be implemented)
@app.get("/export/csv")
def export_csv():
    return JSONResponse({"status": "todo"})

@app.get("/export/google_sheets")
def export_gsheets():
    return JSONResponse({"status": "todo"})
